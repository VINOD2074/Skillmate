//dashboard.js

const openModalBtn = document.getElementById("openModalBtn");
const closeModalBtn = document.getElementById("closeModalBtn");
const domainModal = document.getElementById("domainModal");
const modalOverlay = document.getElementById("modalOverlay");

// Open modal
openModalBtn.addEventListener("click", () => {
  domainModal.classList.add("active");
  modalOverlay.classList.add("active");
});

// Close modal on X click
closeModalBtn.addEventListener("click", () => {
  domainModal.classList.remove("active");
  modalOverlay.classList.remove("active");
});

// Close modal when clicking outside (overlay)
modalOverlay.addEventListener("click", () => {
  domainModal.classList.remove("active");
  modalOverlay.classList.remove("active");
});

// Sidebar toggle
document.addEventListener("DOMContentLoaded", () => {
  const sidebar = document.querySelector(".sidebar"); // sidebar element
  const toggleBtn = document.getElementById("sidebarToggle");

  toggleBtn.addEventListener("click", () => {
    sidebar.classList.toggle("collapsed");
  });
});


// Notification popup toggle
const notificationIcon = document.getElementById("notificationIcon");
const notificationModal = document.getElementById("notificationModal");
const closeNotificationBtn = document.getElementById("closeNotificationBtn");

notificationIcon.addEventListener("click", () => {
  notificationModal.style.display =
    notificationModal.style.display === "block" ? "none" : "block";
});

closeNotificationBtn.addEventListener("click", () => {
  notificationModal.style.display = "none";
});

//
