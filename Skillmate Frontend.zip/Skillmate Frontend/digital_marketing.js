// Sidebar toggle (reuse dashboard.js logic if needed)
const sidebarToggle = document.getElementById("sidebarToggle");
const sidebar = document.querySelector(".sidebar");
const container = document.querySelector(".container");

if (sidebarToggle) {
  sidebarToggle.addEventListener("click", () => {
    sidebar.classList.toggle("collapsed");
    container.classList.toggle("expanded");
  });
}

// Close button → back to dashboard
const closeBtn = document.querySelector(".close-domain");
if (closeBtn) {
  closeBtn.addEventListener("click", () => {
    window.location.href = "dashboard.html";
  });
}
